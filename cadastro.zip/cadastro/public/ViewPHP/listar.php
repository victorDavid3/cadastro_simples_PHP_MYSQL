<?php 
    
    include('ir_home_page.php');

    include_once('../../src/Controller/connection.php');


    $sql = "SELECT * FROM funcionarios ORDER BY id";

    $result = $con ->query($sql);

    $dados_tabela = null;

        while($funcionario_data = mysqli_fetch_assoc($result)){
                $dados_tabela = ($dados_tabela . "<tr><td>".$funcionario_data['id']."</td><td>".$funcionario_data['nome']."</td><tr>");
                }

?>

<!DOCTYPE html>
<html>
    <head>
          <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link href="../CSS/CSS_geral.css" rel="stylesheet" type="text/css"/>
        
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Listar</title>
    </head>
    <body>
        
        <div class="quad">

            <spam class="titulo">Lista de funcionarios</spam>

            <table class="table-responsive" border="1">
                <tr>
                    <td>Cod</td>
                    <td>Nome</td>
                 
                </tr>
               
                    <?php 
                    echo $dados_tabela;
                    ?>

            </table>
        </div>
        
   
    </body>
</html>
