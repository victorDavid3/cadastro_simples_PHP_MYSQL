<?php
 
    include('ViewPHP/ir_home_page.php');
?>

<!DOCTYPE html>

<html>
    <head>
    	<link rel="stylesheet" type="text/css" href="CSS/CSS_geral.css">    
        <title>Cadastro</title>
        <meta charset="UTF-8">
    </head>

    <body>

    	

    	<div class="quad">

    		<h1 class="titulo">sistemas de cadastro</h1>

    		<a href="ViewPHP/cadastrar.php">
             	<div class="quad_menor">
             		<img src="imagens/cadastrar.png" /><span>cadastro</span>
             	</div>
             </a>

             <a href="ViewPHP/listar.php">
            	<div class="quad_menor">
             		<img src="imagens/listar.png" /><span>listar</span>
             	</div>
             </a>

             <a href="ViewPHP/editar.php">
             	<div class="quad_menor">
             		<img src="imagens/editar.png" /><span>editar</span>
             	</div>
             </a>

             <a href="ViewPHP/deletar.php">
             	<div class="quad_menor">
             		<img src="imagens/deletar.png" /><span>deletar</span>
             	</div>
             </a>

        </div>
        
    	
    	</body>
</html>

	<?php

//	use App\Kernel;

//	require_once dirname(__DIR__).'/vendor/autoload_runtime.php';

//	return function (array $context) {
//	    return new Kernel($context['APP_ENV'], (bool) $context['APP_DEBUG']);
//	};


