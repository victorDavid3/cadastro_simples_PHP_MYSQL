<?php

$usuario = 'root';
$senha = '';
$database = 'cadastro';
$host = 'localhost';

$con = mysqli_connect($host, $usuario, $senha, $database);



    if($con -> error){
        die("Falha ao conectar ao banco de dados: " . $mysql -> error);
    }

    
?>