<?php

include_once('connection.php');


    if($con -> error){
        die("Falha ao conectar ao banco de dados: " . $mysql -> error);
    } else{
        
        $nome = htmlspecialchars($_POST["nome"]);

        $query = mysqli_query ($con, "INSERT INTO funcionarios (nome) VALUES ('$nome')");

        echo '<script> 

        alert("Cadastro Realizado");

        window.location.replace("http://localhost/cadastro/public/index.php");

        </script>';

    }

	?>



<!DOCTYPE html>
<html>
    <head>
        
        <link href="../../public/CSS/CSS_geral.css" rel="stylesheet" type="text/css"/>
        
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Salvar</title>
    </head>
    <body>

    <div class="quad">
    	<div class="quad_menor">
    		<span>dados de <?php echo $nome ?> foram salvos</span>
    	</div>
    </div>

    </body>
 </html>