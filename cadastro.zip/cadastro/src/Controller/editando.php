<?php

include_once('connection.php');


    if($con -> error){
        die("Falha ao conectar ao banco de dados: " . $mysql -> error);
    } else{
        
        $id = htmlspecialchars($_POST["ID"]);
        $nome = htmlspecialchars($_POST["nome"]);

        echo $id . $nome;

       $query = mysqli_query ($con, "UPDATE funcionarios SET nome = '$nome' WHERE id = " . $id);

       if($query){
       	echo " update realizado";

       	echo '<script> 

       	alert("Edição Realizada");

       	window.location.replace("http://localhost/cadastro/public/index.php");

       	</script>';


       } else{
       	echo " erro update";

       	echo '<script> 

       	alert("Erro ao editar");

       	window.location.replace("http://localhost/cadastro/public/ViewPHP/editar.php");

       	</script>';

       }

    }

?>

