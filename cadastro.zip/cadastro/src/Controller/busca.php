<?php
        include('../../public/ViewPHP/ir_home_page.php');

        include_once('connection.php');

        $id = htmlspecialchars($_POST["ID"]);
        $result = mysqli_query ($con, "select * from funcionarios where id = " . $id);

        $funcionario_data = mysqli_fetch_assoc($result);

        $id = $funcionario_data['id'];
        $nome = $funcionario_data['nome'];

?>

<!DOCTYPE html>
<html>
    <head>
          
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link href="../../public/CSS/CSS_geral.css" rel="stylesheet" type="text/css"/>

        
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Buscar</title>
    </head>
    <body>

        <div class="quad">
           
             <form name="forms" action="../../src/Controller/editando.php" method="post">
                            
                <span for="ID">ID: <?php echo $id ?></span>

                    
                        <input hidden class="form-control form-control-lg" id="ID" name="ID" type="number" value=<?php echo $id ?>> <br/>
                    

                <span for="nome">Nome</span>
                    <input class="form-control form-control-lg" id="nome" name="nome" type="text" required value=<?php echo $nome ?>> <br/>
                    
                          
                <input type="submit" class="btn btn-primary" name="verificar" value="Salvar edição">
                    
             </form>
        </div>

  </body>

</html>

