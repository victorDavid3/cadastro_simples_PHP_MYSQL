<?php

include_once('connection.php');


    if($con -> error){
        die("Falha ao conectar ao banco de dados: " . $mysql -> error);
    } else{
        
        $id = htmlspecialchars($_POST["ID"]);

       $query = mysqli_query ($con, "DELETE FROM funcionarios WHERE id = " . $id);


       if($query){
        echo "Apagado";

        echo '<script> 

        alert("Deletado");

        window.location.replace("http://localhost/cadastro/public/index.php");

        </script>';


       } else{
        echo " erro deletar";

        echo '<script> 

        alert("Erro ao deletar");

        window.location.replace("http://localhost/cadastro/public/ViewPHP/editar.php");

        </script>';

       }


    }

?>


<!DOCTYPE html>
<html>
    <head>
        
        <link href="../../public/CSS/CSS_geral.css" rel="stylesheet" type="text/css"/>
        
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Deletando</title>
    </head>
    <body>

    <div class="quad">
      <div class="quad_menor">
        <span>dados do ID: <?php echo $id ?> foi deletado</span>
      </div>
    </div>

    </body>
 </html>